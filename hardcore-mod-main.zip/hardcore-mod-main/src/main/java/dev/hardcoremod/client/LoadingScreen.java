package dev.hardcoremod.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Fake loading screen shown after the first element choice.
 * Amethyst background + one progress bar per step.
 */
public class LoadingScreen extends Screen {
    private static final String[] TEXTS = {
            "Đang tạo nhân vật cho bạn....",
            "Chuẩn bị nhân vật cho bạn...",
            "Nhân vật của bạn đã xong!",
            "Tạo thế giới cho bạn...",
            "Chuẩn bị thế giới của bạn...",
            "Tạo thế giới xong rồi!",
            "Chuẩn bị các mob, entity,...",
            "Gần xong rồi",
            "Chúc bạn chơi vui vẻ!",
    };
    private static final int[] DURATIONS = {14, 4, 1, 20, 10, 1, 14, 20, 3};
    private static final int TOTAL = 87;

    private float elapsed;
    private boolean done;

    public LoadingScreen() {
        super(Component.literal("Chuẩn bị mọi thứ cho bạn"));
    }

    /**
     * During loading: block all keyboard. After loading completes: allow
     * everything (ESC / E / inventory close the screen — the Ok button can be
     * off-screen in fullscreen).
     */
    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (!done) return true;
        var client = net.minecraft.client.Minecraft.getInstance();
        if (event.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE
                || event.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_E
                || client.options.keyInventory.matches(event)) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        graphics.blurBeforeThisStratum();
        HcGui.drawAmethystBg(graphics, width, height);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        super.render(graphics, mouseX, mouseY, delta);

        elapsed += delta / 20.0f;
        if (elapsed >= TOTAL && !done) {
            done = true;
            addRenderableWidget(Button.builder(Component.literal("Ok, join the world"), b -> onClose())
                    .bounds(width / 2 - 80, height - 26, 160, 20).build());
        }

        // One stage at a time: current stage text + its progress bar.
        float cum = 0;
        int stage = TEXTS.length - 1;
        float frac = 1;
        for (int i = 0; i < TEXTS.length; i++) {
            float start = cum;
            cum += DURATIONS[i];
            if (elapsed < cum) {
                stage = i;
                frac = Math.max(0, Math.min(1, (elapsed - start) / DURATIONS[i]));
                break;
            }
        }

        HcGui.drawCenteredText(graphics, font, "Chuẩn bị mọi thứ cho bạn", width / 2, 16, 0xFFFFFF);
        HcGui.drawCenteredText(graphics, font, "Bước " + (stage + 1) + " / " + TEXTS.length, width / 2, 30, 0xAAAAAA);

        // Current stage: big text + big progress bar
        HcGui.drawCenteredText(graphics, font, TEXTS[stage], width / 2, height / 2 - 30, 0xFFD54F);
        HcGui.drawProgressBar(graphics, width / 2 - 150, height / 2 - 6, 300, frac);
    }
}
