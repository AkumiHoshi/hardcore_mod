package dev.hardcoremod.client;

import dev.hardcoremod.AdminManager;
import dev.hardcoremod.Element;
import dev.hardcoremod.HcNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class AdminScreen extends Screen {
    private static AdminScreen open;
    private static HcNetworking.AdminStateS2C lastState;

    private final String password;
    private HcNetworking.AdminStateS2C state;
    private int rulePage;
    private boolean needsRebuild = true;

    public AdminScreen(String password) {
        super(Component.literal("Admin Panel"));
        this.password = password;
        this.state = lastState;
        open = this;
    }

    public static void receive(HcNetworking.AdminStateS2C s) {
        lastState = s;
        if (open != null) {
            open.state = s;
            open.needsRebuild = true;
        }
    }

    private void send(String action, int value) {
        ClientPlayNetworking.send(new HcNetworking.AdminActionC2S(password, action, value));
    }

    private void rebuild() {
        clearWidgets();
        if (state == null) return;
        int w = width;
        int h = height;
        int cw = 90;
        int x0 = w / 2 - 190;
        int x1 = w / 2 - 95;
        int x2 = w / 2 + 10;
        int y = 44;
        int[] lvl = {state.strLvl(), state.digLvl(), state.hpLvl()};
        String[] statLabels = {"Sức mạnh " + lvl[0], "Đào " + lvl[1], "Máu " + lvl[2]};
        String[] statActions = {"str", "dig", "hp"};

        for (int i = 0; i < 3; i++) {
            final int idx = i;
            int yy = y + i * 22;
            drawLabel(x0, yy, statLabels[idx]);
            addRenderableWidget(Button.builder(Component.literal("+1"), b -> send(statActions[idx], 1))
                    .bounds(x0 + 70, yy, 40, 18).build());
            addRenderableWidget(Button.builder(Component.literal("+5"), b -> send(statActions[idx], 5))
                    .bounds(x0 + 114, yy, 40, 18).build());
        }
        drawLabel(x0, y + 70, "Points " + state.points());
        addRenderableWidget(Button.builder(Component.literal("+1"), b -> send("points", 1)).bounds(x0 + 70, y + 70, 40, 18).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> send("points", 10)).bounds(x0 + 114, y + 70, 40, 18).build());
        addRenderableWidget(Button.builder(Component.literal("+100"), b -> send("points", 100)).bounds(x0 + 158, y + 70, 46, 18).build());
        drawLabel(x0, y + 92, "Shards " + state.shards());
        addRenderableWidget(Button.builder(Component.literal("+1"), b -> send("shards", 1)).bounds(x0 + 70, y + 92, 40, 18).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> send("shards", 10)).bounds(x0 + 114, y + 92, 40, 18).build());

        String elName = Element.byId(state.element()) != null ? Element.byId(state.element()).name : "Chưa chọn";
        drawLabel(x1, y, "Nguyên tố: " + elName);
        addRenderableWidget(Button.builder(Component.literal("Chọn lại"), b -> send("element", 0)).bounds(x1 + 70, y, 70, 18).build());
        drawLabel(x1, y + 24, "Game mode");
        String[] modes = {"Survival", "Creative", "Adventure", "Spectator"};
        for (int i = 0; i < 4; i++) {
            int mi = i;
            addRenderableWidget(Button.builder(Component.literal(modes[i]), b -> send("gamemode", mi))
                    .bounds(x1 + 70 + (i % 2) * 55, y + 24 + (i / 2) * 20, 52, 18).build());
        }
        drawLabel(x1, y + 66, "Replay");
        addRenderableWidget(Button.builder(Component.literal("Mở Replay"), b -> send("replay", 0)).bounds(x1 + 70, y + 66, 90, 18).build());
        drawLabel(x1, y + 88, "Backup cũ: " + (state.keepOldBackups() ? "GIỮ" : "XÓA"));
        addRenderableWidget(Button.builder(Component.literal("Đổi"), b -> send("keepbackup", 0)).bounds(x1 + 70, y + 88, 90, 18).build());

        // Rules, 5 per page
        drawLabel(x2, y, "Gamerules (trang " + (rulePage + 1) + "/2)");
        for (int i = 0; i < 5; i++) {
            int idx = rulePage * 5 + i;
            if (idx >= AdminManager.RULES.size()) break;
            var entry = AdminManager.RULES.get(idx);
            boolean on = (state.rules() & (1 << idx)) != 0;
            int yy = y + 20 + i * 20;
            drawLabel(x2, yy, (on ? "§2" : "§4") + "● " + entry.label());
            addRenderableWidget(Button.builder(Component.literal(on ? "ON" : "OFF"),
                            b -> send(on ? "rule_off" : "rule_on", idx))
                    .bounds(x2 + 150, yy, 40, 18).build());
        }
        addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            rulePage = 0;
            needsRebuild = true;
        }).bounds(x2, y + 128, 40, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            rulePage = 1;
            needsRebuild = true;
        }).bounds(x2 + 44, y + 128, 40, 18).build());
    }

    private void drawLabel(int x, int y, String text) {
        // drawn in render via stored positions is complex; labels are drawn here on a queue
        labels.add(new int[]{x, y});
        labelTexts.add(text);
    }

    private final java.util.List<int[]> labels = new java.util.ArrayList<>();
    private final java.util.List<String> labelTexts = new java.util.ArrayList<>();

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        graphics.blurBeforeThisStratum();
        HcGui.drawAmethystBg(graphics, width, height);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        if (needsRebuild) {
            needsRebuild = false;
            labels.clear();
            labelTexts.clear();
            rebuild();
        }
        super.render(graphics, mouseX, mouseY, delta);
        HcGui.drawCenteredText(graphics, font, "Admin Panel", width / 2, 24, 0xFFFFFF);
        for (int i = 0; i < labels.size(); i++) {
            int[] p = labels.get(i);
            HcGui.drawText(graphics, font, labelTexts.get(i), p[0], p[1], 0xFFFFFF);
        }
    }

    @Override
    public void onClose() {
        super.onClose();
        open = null;
    }
}
